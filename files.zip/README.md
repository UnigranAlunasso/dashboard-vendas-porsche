# Dashboard de vendas da Porsche

Dashboard interativa em HTML (arquivo único) feita a partir da planilha de 100 vendas da Porsche, publicada no GitHub Pages.

**Dashboard publicada:** [PREENCHER: https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/]

## Perguntas de negócio

1. **Quais modelos geram mais receita?** Mostra onde o faturamento se concentra e se vender muito é o mesmo que faturar muito.
2. **Como a receita evoluiu por ano?** Mostra se o negócio cresce, estabiliza ou cai.
3. **Como os clientes pagam?** Mostra qual método concentra a receita, o que importa para planejar financiamento e caixa.

Filtros: modelo, cidade, ano e método de pagamento. Indicadores de topo: total de vendas, receita total e ticket médio.

## Tratamento da base

- Só as colunas sanitizadas de modelo, cidade, estado, ano, preço e método de pagamento.
- Preço e ano convertidos em número, colados como valores (sem fórmulas).
- Linhas vazias ou `INVALID` são puladas pelo `embutir_dados.py`, que embute os dados no HTML.
- Nenhum dado sensível entrou na base, já que ela fica visível no código da página.

## Ferramenta e prompt

Feita com o **Claude** (chat), sem ChatGPT Canvas nem agente com skill.

Prompt usado:

> Tenho uma planilha com 100 vendas da Porsche (modelo, cidade, estado, ano, preço e método de pagamento). Crie uma dashboard em HTML de arquivo único que responda três perguntas de negócio (modelos com mais receita, evolução da receita por ano, métodos de pagamento), com filtros por modelo, cidade, ano e pagamento, indicadores de topo (vendas, receita, ticket médio) e um visual inspirado nas cores de corrida da Porsche.

O que mudou até a versão final: [PREENCHER: suas iterações, por exemplo trocar uma pergunta, trocar cidade por estado, ajustar cores.]

## Arquivos

- `index.html`: a dashboard.
- `embutir_dados.py`: lê a planilha em CSV (UTF-8) e embute no `index.html`. Uso: `python embutir_dados.py planilha.csv`.

## Como publicar

1. Crie um repositório público na sua conta, com nome em minúsculas e sem acento.
2. Suba `index.html`, `README.md`, e `embutir_dados.py`.
3. Em Settings, Pages, escolha a branch `main` e a pasta raiz.
