"""Embute a planilha (CSV em UTF-8) no index.html.
Uso: python embutir_dados.py planilha.csv [index.html]
Usa as colunas sanitizadas de modelo, cidade, estado, ano, preco e pagamento.
Linhas vazias ou INVALID são puladas."""
import csv, json, re, sys, unicodedata

def n(s): return unicodedata.normalize('NFD', s).encode('ascii', 'ignore').decode().lower()

def num(v):
    s = re.sub(r'[^\d,.\-]', '', str(v))
    if ',' in s: s = s.replace('.', '').replace(',', '.')
    return float(s)

arq = sys.argv[1]
html = sys.argv[2] if len(sys.argv) > 2 else 'index.html'
bruto = open(arq, encoding='utf-8-sig').read().splitlines()
sep = ';' if bruto[0].count(';') > bruto[0].count(',') else ','
linhas = list(csv.DictReader(bruto, delimiter=sep))

def col(k):
    c = [h for h in linhas[0] if k in re.split(r'[^a-z]+', n(h))]
    if not c: sys.exit(f'Coluna "{k}" não encontrada. Colunas do arquivo: {list(linhas[0])}')
    return next((h for h in c if 'sanit' in n(h)), c[0])

M = {k: col(k) for k in ('modelo', 'cidade', 'estado', 'ano', 'preco', 'pagamento')}
dados, pulados = [], 0
for l in linhas:
    try:
        t = {k: l[M[k]].strip() for k in ('modelo', 'cidade', 'estado', 'pagamento')}
        if any(not v or v.upper() == 'INVALID' for v in t.values()): raise ValueError
        dados.append({'m': t['modelo'], 'c': t['cidade'], 'e': t['estado'],
                      'a': int(num(l[M['ano']])), 'p': num(l[M['preco']]), 'pg': t['pagamento']})
    except ValueError:
        pulados += 1

txt = open(html, encoding='utf-8').read()
js = json.dumps(dados, ensure_ascii=False, separators=(',', ':'))
txt = re.sub(r'/\*DADOS_INICIO\*/.*?/\*DADOS_FIM\*/', lambda _: f'/*DADOS_INICIO*/{js}/*DADOS_FIM*/', txt, flags=re.S)
txt = re.sub(r'/\*EXEMPLO\*/\w+/\*FIM_EXEMPLO\*/', '/*EXEMPLO*/false/*FIM_EXEMPLO*/', txt)
open(html, 'w', encoding='utf-8').write(txt)
print(f'{len(dados)} vendas embutidas, {pulados} linhas puladas. Colunas usadas: {M}')
